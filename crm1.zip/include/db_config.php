<?php
$db_host="localhost";
$db_user="boredfqm_wrap";
$db_pass="wrap2earn";
$db_name="boredfqm_wrap";

$connection=@($GLOBALS["___mysqli_ston"] = mysqli_connect($db_host, $db_user, $db_pass));

@((bool)mysqli_query($GLOBALS["___mysqli_ston"], "USE " . $db_name));
echo @((is_object($connection)) ? mysqli_error($connection) : (($___mysqli_res = mysqli_connect_error()) ? $___mysqli_res : false));


$con=mysqli_connect($db_host,$db_user,$db_pass,$db_name);


?>