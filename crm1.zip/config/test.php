<?php 
include '../config/livquikApi.php';
// Example: 
// How to use:

// Read Config
$config_directory_folder = "../config";

//echo $config_directory_folder;

$config = parse_ini_file($config_directory_folder."/livquik.config.ini", true);

/* echo $config; */

//echo var_dump($config);

// Getting data to build url
$proto = $config['livquik']['proto'];
$domain = $config['livquik']['host'];
$api = $config['livquik']['api'];
$type = $config['livquik']['type'];
$partnerid = $config['livquik']['partnerid'];
$path = $config['livquik']['path'];

// Url to call
$url = $proto.$domain.$api.$type.$partnerid.$path;

/* Get from form*/
if(isset($_POST["submit"]))
{
	$mob=$_POST['mobile'];
    $amount=$_POST['amount'];
    $orderid=$_POST['orderid'];
}
/*End*/

//echo '<br>'.$url;

// Example data to post, postFields
// Replace the values with your specific ones
$postFields = Array( 
	"partnerid" => "194",	
	"mobile" => $mob,
	"secret" => "BGTgNcUSKJdYtwLWeRzbUgcPvphmtbjnQ",
	"amount" => $amount,
	"orderid" => $orderid,
	"redirecturl" => "http://wrap2earn.boredbees.com/crm/success.php",
);

// Building post data
$postFields = http_build_query($postFields);

// Initiate object
$curl = new CurlCall;

// Fetching response 
$resp = $curl->post($url, $postFields);

// Decode
$r[][] = json_decode($resp, true);

// Redirecting
header("Location: ". $r['data']['url']);
print_r($r);
// Print the response here
//print_r($r);

// Exit Strategy
exit();

?>